/* global QUnit */

sap.ui.require(["fc/fcupload/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
