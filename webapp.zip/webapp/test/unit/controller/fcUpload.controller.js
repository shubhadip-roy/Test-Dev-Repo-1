/*global QUnit*/

sap.ui.define([
	"fc/fcupload/controller/fcUpload.controller"
], function (Controller) {
	"use strict";

	QUnit.module("fcUpload Controller");

	QUnit.test("I should test the fcUpload controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
