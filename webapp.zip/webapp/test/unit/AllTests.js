sap.ui.define([
	"fc/fcupload/test/unit/controller/fcUpload.controller"
], function () {
	"use strict";
});
