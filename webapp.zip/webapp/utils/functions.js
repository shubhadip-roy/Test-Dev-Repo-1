sap.ui.define(["sap/ui/model/Filter", "sap/ui/model/FilterOperator", "sap/m/TablePersoController" 
],

    function (Filter, FilterOperator, TablePersoController) {

        return {
            //Dynamic M table creation
            createTable: function (arrayC, mTableID, colBindNames, tableItems, makeItemLink, makeItemDateFormatted, makeItemBold, columnShow) {
                if (othat._oTPC) {
                    othat._oTPC.destroy();
                    delete othat._oTPC;
                }
                var array = arrayC;
                var mTable = mTableID;
                var oModel = new sap.ui.model.json.JSONModel();
                var columnData = [];
                var colObj = {};
                var colBindName = colBindNames;
                for (var i = 0; i < colBindName.length; i++) {
                    var colObj = {};
                    var unqArr = array.filter(RC => RC.localName === colBindName[i]);
                    if (unqArr.length > 0) {
                        colObj.coloumnName = unqArr[0].TableName;
                    } else {
                        colObj.coloumnName = colBindName[i];
                    }
                    colObj.colTemp = colBindName[i];
                    columnData.push(colObj);
                }
                oModel.setData({
                    items: tableItems,
                    columns: columnData
                });
                mTable.setModel(oModel);
                var oTemplate = new sap.m.Column({ header: new sap.m.Text({ text: "{coloumnName}", tooltip: "{coloumnName}" }) });
                mTable.bindAggregation("columns", "/columns", oTemplate); //width: "17em",
                // Column Personalization
                // building random number to add column id
                var randomNum1 = Math.floor(Math.random() * 1000) + 1;
                var randomNum2 = Math.floor(Math.random() * 1000) + 2;
                var a = mTable.getColumns();

                if (!columnShow) { // Enable n number of columns or only 10 columns visibility during load of table
                    columnShow = 9; 
                }

                a.forEach(function (value, index) {
                    a[index].sId = randomNum1 + "colId" + randomNum2 + index;
                    if (index > columnShow) {  // Enable 10 column visibility during load of table
                        a[index].setVisible(false);
                    }
                })
                mTable.setAutoPopinMode(false); // Make responsive columns
                var oListTemplate = new sap.m.ColumnListItem();
                for (var i = 0; i < columnData.length; i++) {
                    var oHeaderName = columnData[i].colTemp;
                    // Validating if the list item needs to show as hyperlink
                    if (oHeaderName === makeItemLink) {
                        oListTemplate.addCell(new sap.m.Link({ text: "{" + oHeaderName + "}", tooltip: "{" + oHeaderName + "}", press: function () { othat.showGLAccount(this) } }));
                    } else if (makeItemDateFormatted.includes(oHeaderName)){
                        var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "MM-dd-yyyy"});
                        oListTemplate.addCell(new sap.m.Text({
                            "text": {
                                path: oHeaderName,
                                type: new sap.ui.model.type.Date({ 
                                    formatOptions: {  
                                    pattern: 'MM-dd-yyyy'  
                                    }      
                                })
                            }
                        }));
                    } else {
                        //formatter is added for Numeric values to show with seperators and negative value in brackets.
                        oListTemplate.addCell(new sap.m.Text({
                            "text": {
                                path: oHeaderName,
                            }
                        }));
                        // In case formatter is not required, use the below line of code.
                        //  oListTemplate.addCell(new sap.m.Text({ text: "{" + oHeaderName + "}" }));
                    }
                }
                mTable.bindItems("/items", oListTemplate);
                var sNumPattern = /[0-9,.%]/;
                var sAlphaPattern = /[a-zA-Z]/;
                mTable.getItems()[0].getCells().forEach(function (e, i) {
                    if (sNumPattern.test(e.getText()) && !sAlphaPattern.test(e.getText())) {
                        mTable.getColumns()[i].setHAlign("Right");
                    }
                })
            },




        // Get filter values
        getGlobarFilterValues: function (oModel) {
            var array = [];
            // Project ID
            array.IP_PROJECT_ID = parseInt(oModel.getProperty("/common/ReportFilters/IP_PROJECT_ID"));
            // Company Code
            array.IP_COMPANY_CODE = oModel.getProperty("/common/ReportFilters/IP_COMPANY_CODE");
            // Segment
            array.IP_SEGMENT = JSON.stringify(oModel.getProperty("/common/ReportFilters/IP_SEGMENT"));
            // Fiscal Year
            array.IP_FISCAL_YEAR = oModel.getProperty("/common/ReportFilters/IP_FISCAL_YEAR");
            // Period
            array.IP_PERIOD = JSON.stringify(oModel.getProperty("/common/ReportFilters/IP_PERIOD"));
            // Currency
            array.IP_TO_CURRENCY = oModel.getProperty("/common/ReportFilters/IP_TO_CURRENCY");
            array.IP_PRODUCT = JSON.stringify(oModel.getProperty("/common/ReportFilters/IP_PRODUCT"));
            return array;
        },
        // ****************************GLOBAL PRINT****************************************//

        globalPrint: function (tableId, data, tableHeading, headerDetails) {
            if (tableId) {
                var visibleColumns = [];
                var columnNames = [];
                var tableColumns = tableId.getColumns();
                var tableCols = tableId.getItems()[0].getCells();
                tableCols.forEach(function (t) {
                    if (t.getBinding('text')) {
                        columnNames.push(t.getBinding('text').getPath());
                    } else if (t.getBinding('value')) {
                        columnNames.push(t.getBinding('value').getPath());
                    } else if (t.getItems()[0].getBinding('value')) {
                        columnNames.push(t.getItems()[0].getBinding('value').getPath());
                    }
                });
                tableColumns.forEach(function (value, index) {
                    columnNames.forEach(function (e, ind) {
                        if (index === ind) {
                            value.getHeader().setText(e);
                        }
                    });
                });
                for (var i = 0; i < tableColumns.length; i++) {
                    if (tableColumns[i] && tableColumns[i].getProperty("visible")) { //if (tableColumns[i].getProperty("visible")) {
                        visibleColumns.push(tableColumns[i]);
                    }
                }
                var dataObj = Object.keys(data[0][data[0].length - 1]); //var dataObj = Object.keys(data[0][0]);
                var finalDataArray = [];
                visibleColumns.map((e) => {
                    dataObj.map((i) => {
                        if (e.getHeader().getText() === i) {
                            finalDataArray.push(i);
                        }
                    });
                });
                var dataFrame = [];
                data[0].forEach(function (k) {
                    var obj = {};
                    var dataMap = Object.keys(k);
                    finalDataArray.map((i) => {
                        if (k[i]) {
                            obj[i] = k[i];
                        } else {
                            obj[i] = "";
                        }
                    });
                    dataFrame.push(obj);
                });
                var combinedDataArr = [];
                combinedDataArr.push(dataFrame);
                for (var t = 1; t < data.length; t++) {
                    combinedDataArr.push(data[t]);
                }
                var headerInfo = "";
                if (headerDetails) {
                    var headerDataArr = Object.keys(headerDetails);
                    headerDataArr.forEach(function (e) {
                        if (headerDetails[e]) {
                            headerInfo += e + headerDetails[e] + "<br>";
                        }
                    });
                    this.resusablePrint(combinedDataArr, tableHeading, headerInfo);
                } else {
                    this.resusablePrint(combinedDataArr, tableHeading, headerInfo);
                }
            }
        },

        /*For deleting unwanted keys from array*/
        _removeKeys: function (obj, keys) {
            var that = this;
            var index;
            for (var prop in obj) {
                // important check that this is objects own property
                // not from prototype prop inherited
                if (obj.hasOwnProperty(prop)) {
                    switch (typeof (obj[prop])) {
                        case 'string':
                            index = keys.indexOf(prop);
                            if (index > -1) {
                                delete obj[prop];
                            }
                            break;
                        case 'object':
                            index = keys.indexOf(prop);
                            if (index > -1) {
                                delete obj[prop];
                            } else {
                                that._removeKeys(obj[prop], keys);
                            }
                            break;
                    }
                }
            }
        },

        // ****************************GLOBAL PRINT FOR UI Tables****************************************//
        globalPrintforUI_Table: function (tableId, data, tableHeading, headerDetails) {
            if (tableId) {

                var visibleColumns = [];
                var columnNames = [];
                var tableColumns = tableId.getColumns();
                var tableRows = tableId.getRows()[0].oBindingContexts.undefined.oModel.oData.rows;

                //removing flag key from the rows
                com.ey.tpm.myprojects.util.functions._removeKeys(tableRows, "Flag");

                var dataFrame = tableRows;
                var combinedDataArr = [];
                combinedDataArr.push(dataFrame);
                for (var t = 1; t < data.length; t++) {
                    combinedDataArr.push(data[t]);
                }
                var headerInfo = "";
                if (headerDetails) {
                    var headerDataArr = Object.keys(headerDetails);
                    headerDataArr.forEach(function (e) {
                        if (headerDetails[e]) {
                            headerInfo += e + headerDetails[e] + "<br>";
                        }
                    });
                    this.resusablePrint(combinedDataArr, tableHeading, headerInfo);
                } else {
                    this.resusablePrint(combinedDataArr, tableHeading, headerInfo);
                }
            }
        },
        resusablePrint: function (data, tableHeading, headerInfo) {
            if (!headerInfo) {
                headerInfo = "";
            }
            var myObj = data;
            var txt = "";
            var FinalArrString = [];
            for (var t = 0; t < myObj.length; t++) {
                txt = '<table border="1"" cellpadding="0" cellspacing="0">';
                var ColumnHeaders = [];
                if (myObj[t][0]) {
                    ColumnHeaders = Object.keys(myObj[t][0]);
                }
                txt += "<tr>"
                for (var h = 0; h < ColumnHeaders.length; h++) {
                    txt += "<th>" + ColumnHeaders[h] + "</th>";
                }
                txt += "</tr>";
                for (x in myObj[t]) {
                    var columns = Object.keys(myObj[t][x]);
                    txt += "<tr>"
                    for (var i = 0; i < columns.length; i++) {
                        txt += "<td>" + myObj[t][x][columns[i]] + "</td>";
                    }
                    txt += "</tr>";
                }
                txt += "</table>" + "<br>";
                FinalArrString.push(txt);
            }
            FinalArrString = JSON.stringify(FinalArrString);
            FinalArrString = FinalArrString.replace('["', " ");
            FinalArrString = FinalArrString.replace('","', " ");
            FinalArrString = FinalArrString.replace('"]', " ");
            var string = "<!DOCTYPE html>" + "<html>" + "<head>" + "<title>Page Title</title>" + "<style>" + "th {background: #cccccc;}" +
                "tbody>tr:nth-child(odd)>td {background: #f2f2f2;}" + "td,th {padding: 15px; border: none;}" +
                "*{font-family: sans-serif;}" +
                "</style>" + "</head>" + "<body>" + "<h1>" + tableHeading + "</h1><br>" + headerInfo + FinalArrString + "</body>" + "</html>";
            var w;
            if (sap.ui.Device.browser.name === sap.ui.Device.browser.BROWSER.EDGE) {
                w = window.open();
                w.document.write(string);
            } else if (sap.ui.Device.browser.name === sap.ui.Device.browser.BROWSER.INTERNET_EXPLORER) {
                w = window.open();
                w.document.write(string);
            } else {
                w = window.open();
                $(w.document.body).html(string);
            }
            w.focus();
            w.print();
        },

        //Profit center drop down
        getProfitCenterDropDown: function (oModel) {
            var filters = com.ey.tpm.myprojects.util.functions.getGlobarFilterValues(oModel);
            jQuery.ajax({
                url: GlobalURL + '/projectRoute/getProfitCenter?companyCode=' + filters.IP_COMPANY_CODE,
                type: "GET",
                dataType: "json",
                async: false,
                success: function (result, status, response) {
                    if (result.data) {
                        oModel.setProperty("/myprojects/MoreDetailsModel/IP_PRODUCT", result.data);
                        // placing the PRODUCTS in array for default selection
                        var array = [];
                        result.data.forEach(o => {
                            var obj = {}
                            obj = o.PRODUCT;
                            array.push(obj)
                        })
                        oModel.setProperty("/common/ReportFilters/IP_PRODUCT", array);
                    } else {
                        oModel.setProperty("/myprojects/MoreDetailsModel/IP_PRODUCT", []);
                    }
                }
            });
        },

        //search the table items for all string fields
        globalTableSearch: function (oEvent, oTable) {
            var oItems = oTable.getBinding("items");
            var aFilters = [], oValue = "";
            if (oEvent) {
                oValue = oEvent.getParameter("value");
                if (oValue === undefined) {
                    oValue = oEvent.getSource().getValue();
                }
            }
            if (oTable.getItems().length > 0) {
                var b = oTable.getBinding("items").oList[0];
                var tableCols = oTable.getItems()[0].getCells();
                for (var j = 0, arrCols = ""; j < tableCols.length; j++) {
                    if (tableCols[j].getBindingInfo("text") !== undefined) { //Checking is the column binded with text property
                        arrCols = tableCols[j].getBindingInfo("text").binding.getPath();
                    } else if (tableCols[j].getBindingInfo("value") !== undefined) { //Checking is the column binded with value property
                        arrCols = tableCols[j].getBindingInfo("value").binding.getPath();
                    }
                    if (arrCols && typeof (b[arrCols]) === "string") { // Checking the columns are string, then push
                        aFilters.push(new sap.ui.model.Filter(arrCols, sap.ui.model.FilterOperator.Contains, oValue));
                    }
                }
            } else {
                for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
                    aFilters.push(new sap.ui.model.Filter(
                        oItems.aFilters[0].aFilters[i].sPath, sap.ui.model.FilterOperator.Contains, oValue
                    ));
                }
            }
            if (aFilters.length > 0) {
                var allFilter = new sap.ui.model.Filter(aFilters, false);
                oTable.getBinding("items").filter(allFilter);
            }
        },

        onListSearch: function (oEvent, oListControl) {
            var oItems = oListControl.getBinding("items");
            if (oItems.oList.length > 0) {
                var oValue = oEvent.getParameter("value");
                if (oValue === undefined) {
                    oValue = oEvent.getSource().getValue();
                }
                var aFilters = [];
                if (oListControl.getItems().length > 0) {
                    var oItem = oListControl.getItems()[0];
                    var oFields = Object.keys(oItem.mBindingInfos);
                    for (var i = 0; i < oFields.length; i++) {
                        if (typeof oItem.getBinding(oFields[i]).getValue() === "string") {
                            aFilters.push(new sap.ui.model.Filter(
                                oItem.getBinding(oFields[i]).getPath(), sap.ui.model.FilterOperator.Contains, oValue
                            ));
                        }
                    }
                } else {
                    for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
                        aFilters.push(new sap.ui.model.Filter(
                            oItems.aFilters[0].aFilters[i].sPath, sap.ui.model.FilterOperator.Contains, oValue
                        ));
                    }
                }
                var allFilter = new sap.ui.model.Filter(aFilters, false);
                oListControl.getBinding("items").filter(allFilter);
            }
        },


        // Excel Export Function
        globalExcelExport: function (sdata, sworkSheetName, sfileName) {
            var myResultsArray = sdata;
            // Create a new workbook
            var workSheet = XLSX.utils.json_to_sheet(myResultsArray);
            // Create a new sheet and append to workbook
            var workBook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workBook, workSheet, sworkSheetName);
            var sFilename = sfileName;
            XLSX.writeFile(workBook, sFilename);
        },

        _JSONToCSVConvertor: function (JSONData, sfileName, ReportTitle, ShowLabel) {
            //If JSONData is not an object then JSON.parse will parse the JSON string in an Object
            var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
            var CSV = '';
            //This condition will generate the Label/Header
            if (ShowLabel) {
                var row = "";
                //This loop will extract the label from 1st index of on array
                for (var index in arrData[0]) {
                    //Now convert each value to string and comma-seprated
                    row += index + ',';
                }
                row = row.slice(0, -1);
                //append Label row with line break
                CSV += row + '\r\n';
            }
            //1st loop is to extract each row
            for (var i = 0; i < arrData.length; i++) {
                var row = "";
                //2nd loop will extract each column and convert it in string comma-seprated
                for (var index in arrData[i]) {
                    row += '"' + arrData[i][index] + '",';
                }
                row.slice(0, row.length - 1);
                //add a line break after each row
                CSV += row + '\r\n';
            }
            if (CSV == '') {
                alert("Invalid data");
                return;
            }
            //Initialize file format you want csv or xls
            var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
            /*For IE download CSV*/
            var blob = new Blob([CSV], {
                type: "text/csv;charset=utf-8;"
            });
            if (navigator.msSaveBlob) { // IE 10+
                navigator.msSaveBlob(blob, sfileName);
            } else {
                // Now the little tricky part.
                // you can use either>> window.open(uri);
                // but this will not work in some browsers
                // or you will not get the correct file extension    
                //this trick will generate a temp <a /> tag
                var link = document.createElement("a");
                link.href = uri;
                //set the visibility hidden so it will not effect on your web-layout
                link.style = "visibility:hidden";
                link.download = sfileName;
                //this part will append the anchor tag and remove it after automatic click
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        },


        exportFragment: function (evt, oThat) {
            var oButton = evt.getSource();
            if (!oThat._actionSheet) {
                oThat._actionSheet = sap.ui.xmlfragment("fc.fcupload.view.fragments.DownloadOptions", oThat);
                oThat.getView().addDependent(oThat._actionSheet);
            }
            oThat._actionSheet.openBy(oButton);
        },

        // ***********************GLOBAL TABLE COLUMN SETTINGS START *************************//
        // Table Column Settings
        globalColumnSettings: function (tableId, DemoPersoService) {
            if (othat._oTPC != undefined) {
                if (othat._oTPC.getTable() != tableId.getId()) {
                    othat._oTPC.destroy();
                    othat._oTPC = null;
                    othat._oTPC = new sap.m.TablePersoController({
                        table: tableId,
                        persoService: DemoPersoService
                    }).activate();
                }
            } else {
                othat._oTPC = new sap.m.TablePersoController({
                    table: tableId,
                    persoService: DemoPersoService
                }).activate();
            }
            othat._oTPC.openDialog();
        },
        // *************************GLOBAL TABLE COLUMN SETTINGS END ***************************//

        groupingParticularItemRename: function (rowItems) {
            rowItems.forEach(function (value, index) {
                if (value.GROUPING_PARTICULAR === "Revenue") {
                    value.GROUPING_PARTICULAR = "Net Sales (A1)"
                } else if (value.GROUPING_PARTICULAR === "External Revenue") {
                    value.GROUPING_PARTICULAR = "External Revenue (A2)"
                } else if (value.GROUPING_PARTICULAR === "COGS") {
                    value.GROUPING_PARTICULAR = "Cost Of Goods Sold (COGS) (B)"
                } else if (value.GROUPING_PARTICULAR === "Gross Margin") {
                    value.GROUPING_PARTICULAR = "Gross Margin (C) = (A1) + (A2) + (B)"
                } else if (value.GROUPING_PARTICULAR === "SG&A") {
                    value.GROUPING_PARTICULAR = "SG&A (D)"
                } else if (value.GROUPING_PARTICULAR === "Other Income And Expenses") {
                    value.GROUPING_PARTICULAR = "Other Income And Expenses (E)"
                } else if (value.GROUPING_PARTICULAR === "Operating Margin") {
                    value.GROUPING_PARTICULAR = "Net Income / (Loss) (F) = (C) + (D) + (E)"
                } else if (value.GROUPING_PARTICULAR === "PLI") {
                    value.GROUPING_PARTICULAR = "Target Profit Level Indicator (PLI) (J)"
                } else if (value.GROUPING_PARTICULAR === "GAAP/STAT Adjustment") {
                    value.GROUPING_PARTICULAR = "GAAP/STAT Adjustment (G)"
                } else if (value.GROUPING_PARTICULAR === "Stat Operating Margin") {
                    value.GROUPING_PARTICULAR = "Stat Operating Margin (H) = (C) + (D) + (G)"
                } else if (value.GROUPING_PARTICULAR === "Operating Margin % of Sales") {
                    value.GROUPING_PARTICULAR = "Operating Margin % of Sales (I) = (H) / (A1)"
                } else if (value.GROUPING_PARTICULAR === "Target Operating Profit") {
                    value.GROUPING_PARTICULAR = "Target Operating Profit (K) = (J) * (A1)"
                } else if (value.GROUPING_PARTICULAR === "Proposed Profitability Adjustment") {
                    value.GROUPING_PARTICULAR = "Proposed Profitability Adjustment (L) = (K) - (H)"
                } else if (value.GROUPING_PARTICULAR === "Operating Margin Target: Upper Bound") {
                    value.GROUPING_PARTICULAR = "Operating Margin Target: Upper Bound (M)"
                } else if (value.GROUPING_PARTICULAR === "Operating Margin Target: Lower Bound") {
                    value.GROUPING_PARTICULAR = "Operating Margin Target: Lower Bound (N)"
                } else if (value.GROUPING_PARTICULAR === "Final Profitability Adjustment") {
                    value.GROUPING_PARTICULAR = "Final Profitability Adjustment (O) = If (M) > (I) > (N), zero, otherwise (L)"
                } else if (value.GROUPING_PARTICULAR === "Gross Margin %") {
                    value.GROUPING_PARTICULAR = "Gross Margin % (P) = (C) / (A1)"
                } else if (value.GROUPING_PARTICULAR === "SG&A % of Sales") {
                    value.GROUPING_PARTICULAR = "SG&A % of Sales (Q) = (D) / (A1)"
                } else if (value.GROUPING_PARTICULAR === "Forecasted Operating Margin") { // added for pricing simulation
                    value.GROUPING_PARTICULAR = "Forecasted Operating Margin (A)"
                } else if (value.GROUPING_PARTICULAR === "Forecasted Operating Margin %") {
                    value.GROUPING_PARTICULAR = "Forecasted Operating Margin % (B)"
                } else if (value.GROUPING_PARTICULAR === "Difference between Forecasted OP and OP to align with target") {
                    // value.GROUPING_PARTICULAR = "Difference between Forecasted OP and OP to align with target (C) = (A) - (B)"
                    value.GROUPING_PARTICULAR = "Required Adjustment (E) = (D - A)"
                } else if (value.GROUPING_PARTICULAR === "Target OP %") {
                    value.GROUPING_PARTICULAR = "Target OP % (C)"
                } else if (value.GROUPING_PARTICULAR === "Required Operating Profit to bring forecasted operating profit  in alignment with target") {
                    // value.GROUPING_PARTICULAR = "Required Operating Profit to bring forecasted operating profit (B)"
                    value.GROUPING_PARTICULAR = "Target Operating Margin (D)"
                } else if (value.GROUPING_PARTICULAR === "Target Operating % Profit Price Change") {
                    value.GROUPING_PARTICULAR = "Target Operating % Profit Price Change (F) = (E) - (D)"
                } else if (value.GROUPING_PARTICULAR === "Customs/Duties") {
                    value.GROUPING_PARTICULAR = "Custom Duties (I)"
                } else if (value.GROUPING_PARTICULAR === "Average Estimated Selling Price as per Actual Sales") {
                    // value.GROUPING_PARTICULAR = "Average Estimated Selling Price as per Actual Sales (H)"
                    value.GROUPING_PARTICULAR = "Forecasted Average Selling Price (G)"
                } else if (value.GROUPING_PARTICULAR === "Forecasted Volume (Inventory yet be produced)") {
                    // value.GROUPING_PARTICULAR = "Forecasted Volume (Inventory yet be produced) (G)"
                    value.GROUPING_PARTICULAR = "Forecasted Volume to be produced (F)"
                } else if (value.GROUPING_PARTICULAR === "Amount Adjusted in above inventory") {
                    value.GROUPING_PARTICULAR = "Amount Adjusted in above inventory (M) = (I) * (G)"
                } else if (value.GROUPING_PARTICULAR === "Change in Price per Unit Before Customs/Duties Adjustments") {
                    // value.GROUPING_PARTICULAR = "Change in Price per Unit Before Customs/Duties Adjustments (I) = (C) / (G)"
                    value.GROUPING_PARTICULAR = "Required Average Price change (H) = (E/F)"
                } else if (value.GROUPING_PARTICULAR === "Total Change in Price per Unit") {
                    // value.GROUPING_PARTICULAR = "Total Change in Price per Unit (K) = (I) - (J)"
                    value.GROUPING_PARTICULAR = "Price Change (J) = (H + I)"
                } else if (value.GROUPING_PARTICULAR === "% Price Change per Unit After Customs/Other Adjustments") {
                    value.GROUPING_PARTICULAR = "% Price Change per Unit After Customs/Other Adjustments (L) = (K) / (H)"
                    value.GROUPING_PARTICULAR = "Price Change % (L) = (J/G)"
                } else if (value.GROUPING_PARTICULAR === "Custom Rate %") {
                    value.GROUPING_PARTICULAR = "Custom Rate % (D)"
                } else if (value.GROUPING_PARTICULAR === "Custom Sensitivity Lower Range %") {
                    value.GROUPING_PARTICULAR = "Custom Sensitivity Lower Range % (E)"
                } else if (value.GROUPING_PARTICULAR === "Custom Sensitivity Upper Range %") {
                    value.GROUPING_PARTICULAR = "Custom Sensitivity Upper Range % (F)"
                } else if (value.GROUPING_PARTICULAR === "Average Price per Unit as per Actual") {
                    value.GROUPING_PARTICULAR = "Average Price per Unit as per Actual (G)"
                } else if (value.GROUPING_PARTICULAR === "Price with Custom Lower Range Impact") {
                    value.GROUPING_PARTICULAR = "Price with Custom Lower Range Impact (H) = G * (1 + E)"
                } else if (value.GROUPING_PARTICULAR === "Price with Custom Upper Range Impact") {
                    value.GROUPING_PARTICULAR = "Price with Custom Upper Range Impact (I) = G * (1 + F)"
                } else if (value.GROUPING_PARTICULAR === "New Target Price w/o Custom Effect") {
                    value.GROUPING_PARTICULAR = "New Target Price w/o Custom Effect (J)"
                } else if (value.GROUPING_PARTICULAR === "New Target Price w/o Custom Effect") {
                    value.GROUPING_PARTICULAR = "New Target Price w/o Custom Effect (J)"
                } else if (value.GROUPING_PARTICULAR === "Amount per unit that cannot be absorbed in upper custom limit") {
                    value.GROUPING_PARTICULAR = "Amount per unit that cannot be absorbed in upper custom limit (K) = (J) - (H)"
                } else if (value.GROUPING_PARTICULAR === "Inventory to be Produced") {
                    value.GROUPING_PARTICULAR = "Inventory to be Produced (L)"
                } else if (value.GROUPING_PARTICULAR === "Retrospective Adjustment") {
                    value.GROUPING_PARTICULAR = "Retrospective Adjustment (M) = (L) * (K)"
                } else if (value.GROUPING_PARTICULAR === "Prospective Adjustment") {
                    value.GROUPING_PARTICULAR = "Prospective Adjustment (N)"
                } else if (value.GROUPING_PARTICULAR === "Total Adjustment") {
                    value.GROUPING_PARTICULAR = "Total Adjustment (O) = (M) + (N)"
                } else if (value.GROUPING_PARTICULAR === "Income Tax") {
                    value.GROUPING_PARTICULAR = "Net Income / (Loss) (F) = (D) + (E)"
                }
            });
        },

        // ************************GLOBAL TABLE PERSONALIZATION START **************************//
        // Creating Personalization Dialog   
        _createPersonalizationDialog: function (evt, mTableID, othat) {
            if (sap.ui.getCore()._osortingFilteringDialog === undefined || sap.ui.getCore()._osortingFilteringDialog.length === 0) {
                sap.ui.getCore()._osortingFilteringDialog = new sap.ui.xmlfragment
                    ("fc.fcupload.view.fragments.Personalization", othat);
                othat.getView().addDependent(sap.ui.getCore()._osortingFilteringDialog);
            }
            // removing items
            sap.ui.getCore()._osortingFilteringDialog.removeAllSortItems();
            sap.ui.getCore()._osortingFilteringDialog.removeAllFilterItems();
            sap.ui.getCore()._osortingFilteringDialog.removeAllGroupItems();
            // create items dynamically referring to table columns
            this.createSortItems(mTableID, othat);
            this.createFilterItems(mTableID, othat);
            this.createGroupItems(mTableID, othat);

            sap.ui.getCore()._osortingFilteringDialog.open(evt.getSource());
        },

        // Creating Sort Items
        createSortItems: function (mTableID, othat) {
            // looping over table columns
            var tableColumns = mTableID.getColumns();
            var keyArr = [];
            for(var i=0;i<tableColumns.length;i++){
                if(mTableID.getAggregation("columns")[i]){
                    keyArr.push(mTableID.getAggregation("columns")[i].getAggregation("header").getText());
                }
            }
            var defaultSelected = false;
            // ******** matching column and row length to get all column names in personalization - start
            var columnLength, keyArr;
            // ******** matching column and row length to get all column names in personalization - end
            // picking table second row, if not available then the 1st one. 
            // if (tableRows[1]) {
            //     keyArr = Object.keys(tableRows[1]);
            // } else {
            //     keyArr = Object.keys(tableRows[0]);
            // }
            keyArr = keyArr.filter(function(f) { return f !== 'Flag' });
            keyArr.forEach(function (e, index) {
                if (index === 0) {
                    // defaulting first item to selected
                    defaultSelected = true;
                }
                var items = new sap.m.ViewSettingsItem({
                    text: e,
                    key: e,
                    selected: defaultSelected
                });
                sap.ui.getCore()._osortingFilteringDialog.addSortItem(items);
            });
        },

        // Creating Filter Items
        createFilterItems: function (mTableID, othat) {
            var tableRows = mTableID.getBinding("items")["oList"];
            // ******** matching column and row length to get all column names in personalization - start
            var columnLength, keyArr;
            // ******** matching column and row length to get all column names in personalization - end
            // picking table second row, if not available then the 1st one. 
            // if (tableRows[1]) {
            //     keyArr = Object.keys(tableRows[1]);
            // } else {
            //     keyArr = Object.keys(tableRows[0]);
            // }
            var tableColumns = mTableID.getColumns();
            var keyArr = [];
            for(var i=0;i<tableColumns.length;i++){
                if(mTableID.getAggregation("columns")[i]){
                    keyArr.push(mTableID.getAggregation("columns")[i].getAggregation("header").getText());
                }
            }
            keyArr = keyArr.filter(function(f) { return f !== 'Flag' });
            keyArr.forEach(function (e) {
                var items = new sap.m.ViewSettingsFilterItem({
                    text: e,
                    key: e
                });
                tableRows.forEach(function (k) {
                    var viewSettingsItem = new sap.m.ViewSettingsItem({ text: k[e], key: k[e] });
                    if (items.getItems().filter(RC => RC.getKey() === viewSettingsItem.getKey()).length > 0) {
                    } else {
                        items.addItem(viewSettingsItem);
                    }
                });
                sap.ui.getCore()._osortingFilteringDialog.addFilterItem(items);
            });
        },

        // Creating Group Items
        createGroupItems: function (mTableID, othat) {
            var tableRows = mTableID.getBinding("items")["oList"];
            // ******** matching column and row length to get all column names in personalization - start
            var columnLength, keyArr;
            // ******** matching column and row length to get all column names in personalization - end
            // picking table second row, if not available then the 1st one. 
            // if (tableRows[1]) {
            //     keyArr = Object.keys(tableRows[1]);
            // } else {
            //     keyArr = Object.keys(tableRows[0]);
            // }
            var tableColumns = mTableID.getColumns();
            var keyArr = [];
            for(var i=0;i<tableColumns.length;i++){
                if(mTableID.getAggregation("columns")[i]){
                    keyArr.push(mTableID.getAggregation("columns")[i].getAggregation("header").getText());
                }
            }
            keyArr = keyArr.filter(function(f) { return f !== 'Flag' });
            keyArr.forEach(function (e) {
                var items = new sap.m.ViewSettingsItem({
                    text: e,
                    key: e,
                    selected: false
                });
                sap.ui.getCore()._osortingFilteringDialog.addGroupItem(items);
            });
        },

        //Handling Personalization on press of OK
        handlePersonalization: function (evt, mTableID) {
            var p = evt.getParameters(),
                sSortPath = null,
                oSorter,
                sGroupPath = null,
                oGroupFunction = null,
                oGrouper,
                aFilters = null,
                oCallback = null,
                aTableSorters = [],
                aTableFilters = []
            var sortDialog = evt.getSource();
            var sortitems = sortDialog.getSortItems();
            var filteritems = sortDialog.getFilterItems();
            //  Sequence is Important for Personalization and should be as follows GROUPING, SORTING AND FILTERING
            // Grouping Items
            if (p.groupItem) {
                var sPath = p.groupItem.getKey();
                var bDescending = p.groupDescending;
                aTableSorters.push(new sap.ui.model.Sorter(sPath, bDescending, true));
            }
            // create sorter
            sSortPath = p.sortItem.getKey();
            if (sSortPath) {
                oSorter = new sap.ui.model.Sorter(sSortPath, p.sortDescending);
                aTableSorters.push(oSorter);
            }
            //  filtering (either preset filters or standard/custom filters)
            if (p.filterItems) {
                var filterKeys = Object.keys(p.filterCompoundKeys);
                for (var i = 0; i < filterKeys.length; i++) {
                    var filterValues = Object.keys(p.filterCompoundKeys[filterKeys[i]]);
                    for (var j = 0; j < filterValues.length; j++) {
                        aFilters = new sap.ui.model.Filter(filterKeys[i], sap.ui.model.FilterOperator.EQ, filterValues[j]);
                        // add filters
                        if (aFilters) {
                            // the filter could be an array of filters or a single filter so we transform it to an array
                            if (!Array.isArray(aFilters)) {
                                aFilters = [aFilters];
                            }
                            aTableFilters = aTableFilters.concat(aFilters);
                        }
                    }
                }
            }
            mTableID.getBinding("items").sort(aTableSorters);
            mTableID.getBinding("items").filter(aTableFilters);
            // To resolve Duplicate ID issue in different apps at Launchpad level
            //  sap.ui.getCore()._osortingFilteringDialog = undefined;
        },

        //******For keeping only selected keys in a array ******/
        globalSelectedKeys: function (keys_to_keep, arrayData) {
            var redux = array => array.map(o => keys_to_keep.reduce((acc, curr) => {
                acc[curr] = o[curr];
                return acc;
            }, {}));
            return redux(arrayData);
        },

        createMultiHeaderUiTable: function (arrayC, mTableID, colBindNames, columnData, tableItems, makeItemLink) {
            var array = arrayC;
            var mTable = mTableID;
            var oModel = new sap.ui.model.json.JSONModel();
            // var columnData = [];
            var colObj = {};
            var colBindName = colBindNames;

            var oModel = new sap.ui.model.json.JSONModel();
            oModel.setData({
                rows: tableItems,
                columns: columnData
            });
            mTable.setModel(oModel);

            mTable.bindColumns("/columns", function (sId, oContext) {
                var columnName = oContext.getObject().columnName;
                var colTemp = oContext.getObject().colTemp;
                var multi = oContext.getObject().multi;
                var span = oContext.getObject().span;
                var CompCode = oContext.getObject().CompanyCode;
                var CompCode2 = oContext.getObject().ServiceName;
                var width = "20rem";
                var textAlign = "Right";
                var oDesign = "Standard";
                var oJustifyContent = "Center";
                var oStyleClass = "sapUiSmallMarginEnd"
                var oCellItem;

                //For 1st cloumn GRP
                if (colTemp === "GROUPING_PARTICULAR") {
                    textAlign = "Left";
                    width = "20rem";
                    oDesign = "Bold";
                    oJustifyContent = "Start";
                    oStyleClass = "sapUiSmallMarginBegin boldFont";
                    oCellItem = new sap.m.Link({
                        text: "{" + colTemp + "}",
                        tooltip: "{" + colTemp + "}"
                    });
                } else {
                    oCellItem = new sap.m.Text({ /*START - Add sap.m.Input*/
                        textAlign: textAlign,
                        width: width,
                        enabled: false,
                        /*START - Add sap.m.Input */
                        "text": { /*START - Add sap.m.Input */
                            path: colTemp
                        },
                        tooltip: {
                            path: colTemp
                        },
                        design: oDesign,
                        wrapping: true
                    }).addStyleClass(oStyleClass);
                }

                var sCol = new sap.ui.table.Column({
                    headerSpan: span,
                    sortProperty: colTemp,
                    filterProperty: colTemp,
                    width: width,
                    multiLabels: [
                        new sap.m.Text({
                            text: CompCode,
                            textAlign: "Center",
                            width: '100%',
                            design: "Bold"
                        }).addStyleClass('sapMLabelWhite'),
                        new sap.m.Text({
                            text: CompCode2,
                            textAlign: "Center",
                            width: '100%',
                            design: "Bold"
                        }).addStyleClass('sapMLabelWhite'),
                        new sap.m.Text({
                            text: columnName,
                            textAlign: "Center",
                            width: '100%',
                            design: "Bold"
                        }).addStyleClass('sapMLabelWhite')
                    ],
                    hAlign: "Begin",
                    template: new sap.m.HBox({
                        justifyContent: oJustifyContent,
                        items: [
                            oCellItem
                            // new sap.m.Text({ /*START - Add sap.m.Input*/
                            //     textAlign: textAlign,
                            //     width: width,
                            //     enabled: false,
                            //     /*START - Add sap.m.Input */
                            //     "text": { /*START - Add sap.m.Input */
                            //         path: colTemp
                            //     },
                            //     tooltip: {
                            //         path: colTemp
                            //     },
                            //     design: oDesign,
                            //     wrapping: true
                            // }).addStyleClass(oStyleClass)
                        ]
                    })

                });
                return sCol;
            });

            mTable.bindRows("/rows");

            //adding column header bg black css
            mTable.addStyleClass("sapUiTableHeaderRowBlackCustom");

        },
        // ************************GLOBAL MULTIHEADER UI TABLE ENDS **************************//

        //*************************Information popups for FY,Period,Currency******************//
        onReportInformation: function (evt, oThat) {
            var oSource = evt.getSource();
            if (!oThat._informationPopup) {
                oThat._informationPopup = sap.ui.xmlfragment("com.ey.tpm.myprojects.fragments.ReportInfoPopup", oThat);
                oThat.getView().addDependent(oThat._informationPopup);
            }
            oThat._informationPopup.openBy(oSource);
        },

        onCloseReportInformation: function (oThat) {
            oThat._informationPopup.close();
            // oThat._informationPopup.destroy();
            // oThat._informationPopup = null;
        },

        // *************************GLOBAL JS ARRAY SORT START ***************************//
        //Array sorting in ascending order
        arraySortAsc: function (array, keyName) {
            var sortedArray = array.sort(function (a, b) {
                return a.keyName - b.keyName
            });
            return sortedArray;
        },

        //Array sorting in descending order
        arraySortDesc: function (array, keyName) {
            var sortedArray = array.sort(function (a, b) {
                return b.keyName - a.keyName
            });
            return sortedArray;
        },
            // *************************GLOBAL JS ARRAY SORT END ***************************//
            
        // *************************GLOBAL ROW BOLD START ******************************//
        tableListFormat: function (oTableID, ind2, index) {
            oTableID.getItems()[index].mAggregations.cells[ind2].addStyleClass("boldFont");
            oTableID.getItems()[index].addStyleClass("rowGrey");
        },
        // *************************GLOBAL ROW BOLD END ********************************//

        // ************************** Value Help Pop Up Integration Start *********************//
        // get company code in value help
            onClickOpenCompanyCode: function (oEvent, oModel, oThat) {
                if (!oThat._oCompanyDialogFragment) {
                    oThat._oCompanyDialogFragment = new sap.ui.xmlfragment("fc.fcupload.view.fragments.CompanyCodeValueHelp", oThat);
                    //oThat._oCompanyDialogFragment.setModel(oModel);
                    oThat.getView().addDependent(oThat._oCompanyDialogFragment);
                    oThat._oCompanyDialogFragment.getBinding("items").filter(null);
                    oThat._oCompanyDialogFragment.open();
                } else {
                    oThat._oCompanyDialogFragment.getBinding("items").filter(null);
                    oThat._oCompanyDialogFragment.open();
                }
            },

            // get company code value help search
            onListSearch: function (oEvent, oListControl) {
                var oItems = oListControl.getBinding("items");
                if (oItems.oList.length > 0) {
                    var oValue = oEvent.getParameter("value");
                    if (oValue === undefined) {
                        oValue = oEvent.getSource().getValue();
                    }
                    var aFilters = [];
                    if (oListControl.getItems().length > 0) {
                        var oItem = oListControl.getItems()[0];
                        var oFields = Object.keys(oItem.mBindingInfos);
                        for (var i = 0; i < oFields.length; i++) {
                            if (typeof oItem.getBinding(oFields[i]).getValue() === "string") {
                                aFilters.push(new Filter(
                                    oItem.getBinding(oFields[i]).getPath(), sap.ui.model.FilterOperator.Contains, oValue
                                ));
                            }
                        }
                    } else {
                        for (var i = 0; i < oItems.aFilters[0].aFilters.length; i++) {
                            aFilters.push(new Filter(
                                oItems.aFilters[0].aFilters[i].sPath, sap.ui.model.FilterOperator.Contains, oValue
                            ));
                        }
                    }
                    var allFilter = new Filter(aFilters, false);
                    oListControl.getBinding("items").filter(allFilter);
                }
            },

            
            // get customer in value help
            onClickOpenCustomer: function (oEvent, oModel, oThat) {
                if (!oThat._oCustomerDialogFragment) {
                    oThat._oCustomerDialogFragment = new sap.ui.xmlfragment("fc.fcupload.view.fragments.CustomerValueHelp", oThat);
                    oThat.getView().addDependent(oThat._oCustomerDialogFragment);
                    oThat._oCustomerDialogFragment.getBinding("items").filter(null);
                    oThat._oCustomerDialogFragment.open();
                } else {
                    oThat._oCustomerDialogFragment.getBinding("items").filter(null);
                    oThat._oCustomerDialogFragment.open();
                }
            },

            onClickOpenGLAccount: function (oEvent, oModel, oThat) {
                if (!oThat._oGLAccountDialogFragment) {
                    oThat._oGLAccountDialogFragment = new sap.ui.xmlfragment("fc.fcupload.view.fragments.GLAccountValueHelp", oThat);
                    oThat.getView().addDependent(oThat._oGLAccountDialogFragment);
                    oThat._oGLAccountDialogFragment.getBinding("items").filter(null);
                    oThat._oGLAccountDialogFragment.open();
                } else {
                    oThat._oGLAccountDialogFragment.getBinding("items").filter(null);
                    oThat._oGLAccountDialogFragment.open();
                }
            },
            
        
        }
    })
